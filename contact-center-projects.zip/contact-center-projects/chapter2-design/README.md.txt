# Chapter 2: Design

Key design activities focus on defining the target architecture, integrating new systems, and ensuring security and compliance for the migration to WxCC.
